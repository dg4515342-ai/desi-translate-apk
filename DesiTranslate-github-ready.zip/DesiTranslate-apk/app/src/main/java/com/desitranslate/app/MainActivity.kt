package com.desitranslate.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout

// Apna public link yahan dalo (Save ke baad jo naam mile wahi).
// Jaise: https://perchance.org/xxxx
const val APP_URL = "https://perchance.org/minimal"

class MainActivity : Activity() {

    private lateinit var web: WebView

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val btn = Button(this).apply {
            text = "💬 Floating bubble chalu karo"
            setOnClickListener { ensureOverlayThenStart() }
        }
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
        }
        col.addView(btn)
        col.addView(web, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT, 1f))
        setContentView(col)

        web.loadUrl(startUrl(intent))
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        web.loadUrl(startUrl(i))
    }

    private fun startUrl(i: Intent?): String {
        if (i?.action == Intent.ACTION_SEND) {
            val t = i.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()?.trim().orEmpty()
            if (t.isNotEmpty()) return APP_URL + "?text=" + Uri.encode(t.take(500))
        }
        return APP_URL
    }

    private fun ensureOverlayThenStart() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
            return
        }
        startService(Intent(this, FloatingBubbleService::class.java).apply {
            putExtra("url", APP_URL)
        })
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
