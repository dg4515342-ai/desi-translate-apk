package com.desitranslate.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import kotlin.math.abs

// Har app ke upar tairta 💬 bubble. Tap = translator kholo, drag = move karo.
class FloatingBubbleService : Service() {

    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var appUrl: String = APP_URL

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        i?.getStringExtra("url")?.let { if (it.isNotBlank()) appUrl = it }
        startFg()
        if (bubble == null) addBubble()
        return START_STICKY
    }

    private fun startFg() {
        val ch = "bubble"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(
                ch, "Floating bubble", NotificationManager.IMPORTANCE_MIN))
        }
        val n: Notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, ch)
                .setContentTitle("Desi Translate bubble chal raha hai")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Desi Translate bubble chal raha hai")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build()
        }
        startForeground(1, n)
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    @SuppressLint("ClickableViewAccessibility")
    private fun addBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = Button(this).apply {
            text = "💬"
            textSize = 26f
            setBackgroundColor(Color.parseColor("#1E7BFF"))
            setTextColor(Color.WHITE)
        }
        val p = WindowManager.LayoutParams(
            170, 170,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40; y = 400
        }
        var dx = 0; var dy = 0; var sx = 0; var sy = 0; var moved = 0
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = p.x; sy = p.y; dx = e.rawX.toInt(); dy = e.rawY.toInt(); moved = 0
                }
                MotionEvent.ACTION_MOVE -> {
                    val nx = sx + (e.rawX.toInt() - dx)
                    val ny = sy + (e.rawY.toInt() - dy)
                    moved += abs(nx - p.x) + abs(ny - p.y)
                    p.x = nx; p.y = ny
                    try { wm.updateViewLayout(b, p) } catch (_: Exception) {}
                }
                MotionEvent.ACTION_UP -> {
                    if (moved < 12) togglePanel()
                }
            }
            true
        }
        wm.addView(b, p)
        bubble = b
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun togglePanel() {
        if (panel != null) {
            try { wm.removeView(panel) } catch (_: Exception) {}
            panel = null
            return
        }
        val lay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#0AA5C2"))
            setPadding(16, 16, 16, 16)
        }
        val close = Button(this).apply {
            text = "✕"
            setOnClickListener { togglePanel() }
        }
        bar.addView(close)
        val web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            loadUrl(appUrl)
        }
        lay.addView(bar)
        lay.addView(web, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            900))
        val p = WindowManager.LayoutParams(
            950, 1250,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.CENTER
        }
        // Panel ko header se drag karne ke liye
        var fx = 0; var fy = 0; var px = 0; var py = 0
        bar.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { fx = e.rawX.toInt(); fy = e.rawY.toInt(); px = p.x; py = p.y }
                MotionEvent.ACTION_MOVE -> {
                    p.x = px + (e.rawX.toInt() - fx)
                    p.y = py + (e.rawY.toInt() - fy)
                    try { wm.updateViewLayout(lay, p) } catch (_: Exception) {}
                }
            }
            true
        }
        val wrap = FrameLayout(this).apply { addView(lay) }
        wm.addView(wrap, p)
        panel = wrap
    }

    override fun onDestroy() {
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        super.onDestroy()
    }
}
